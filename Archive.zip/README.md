This is a page for my anime.js practice
Also there is a folder for particle.js practice
This readme file will be build step by step as I go with the practice too. 
